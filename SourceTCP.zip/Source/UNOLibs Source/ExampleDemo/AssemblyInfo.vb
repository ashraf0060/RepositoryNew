Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Le informazioni generali relative a un assembly sono controllate dal seguente
' insieme di attributi. Per modificare le informazioni associate a un assembly 
' occorre quindi modificare i valori di questi attributi.

' Rivedere i valori degli attributi dell'assembly.

<Assembly: AssemblyTitle("ExampleDemo.exe")> 
<Assembly: AssemblyDescription("Demo for UNOLibs.Net.dll")> 
<Assembly: AssemblyCompany("uno team")> 
<Assembly: AssemblyProduct("UNOLibs.Net")> 
<Assembly: AssemblyCopyright("uno team")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 
<Assembly: AssemblyVersion("1.0.0.1")> 

'Se il progetto viene esposto a COM, il GUID che segue verr� utilizzato per creare l'ID della libreria dei tipi.
<Assembly: Guid("0D3C2258-8477-4FA8-A827-B5D9498F136C")> 

' Le informazioni sulla versione di un assembly sono costituite dai seguenti valori:
'
'      Numero di versione principale
'      Numero di versione secondario 
'      Numero build
'      Revisione
'
' � possibile specificare tutti i valori oppure impostare valori predefiniti per i numeri relativi alla revisione e alla build
' utilizzando il carattere "*" come mostrato di seguito:


