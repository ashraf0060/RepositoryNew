Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Le informazioni generali relative a un assembly sono controllate dal seguente
' insieme di attributi. Per modificare le informazioni associate a un assembly 
' occorre quindi modificare i valori di questi attributi.

' Rivedere i valori degli attributi dell'assembly.

<Assembly: AssemblyTitle("UNOLibs.Net")> 
<Assembly: AssemblyDescription("UnoLibs libary special CodeProject Version")> 
<Assembly: AssemblyCompany("uno team")> 
<Assembly: AssemblyProduct("UNOLibs.Net")> 
<Assembly: AssemblyCopyright("uno team")> 
<Assembly: AssemblyTrademark("uno team")> 
<Assembly: AssemblyVersion("1.2.0.1")> 
<Assembly: CLSCompliant(True)> 

'Se il progetto viene esposto a COM, il GUID che segue verr� utilizzato per creare l'ID della libreria dei tipi.
<Assembly: Guid("027229CB-9915-4FB5-B334-9D702141B024")> 

' Le informazioni sulla versione di un assembly sono costituite dai seguenti valori:
'
'      Numero di versione principale
'      Numero di versione secondario 
'      Numero build
'      Revisione
'
' � possibile specificare tutti i valori oppure impostare valori predefiniti per i numeri relativi alla revisione e alla build
' utilizzando il carattere "*" come mostrato di seguito:
